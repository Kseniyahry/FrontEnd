<template>
  <Header avaPath="/src/assets/dog.png" />
  <div class="container-posts">
    <Post
    v-for="(post, index) of posts"
    :id="post.id"
    :current-time="post.currentTime"
    :key="index"
    :itemsList="post.itemsList"
    :userName="post.userName"
    :likes="post.likes"
    />
  </div>
  <Dock @create-post="addPost" />
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import Header from '../components/Header.vue';
import Post from '../components/Post.vue';
import Dock from '../components/Dock.vue';
import type { Item, PostItem } from '../types.ts'
import axios from 'axios';

export default defineComponent({
  name: 'App',
  components: {
    Header,
    Post,
    Dock,
  },
  data() {
    return {
      posts: [
        {
          id: "0",
          currentTime: "1970-01-01T00:00:00Z",
          itemsList: [
            {
              type: 'text',
              content: 'Доброго дня, Вас вітає адміністрація серверу. Правила => цуценя дозволено лайкати багато разів. За чіти – бан. За непристойну брань – бан. За непристойну брань на цуценя – бан. Бажаю успіхів!',
            },
            { type: 'image', src: '/src/assets/dog.png', alt: 'Image 0' },
          ] as Item[],
          userName: 'Admins',
          likes: 1337,
        },
      ],
    };
  },
  methods: {
    async addPost(newPostItems: PostItem[]) {
      // Створюємо масив itemsList на основі newPostItems
      const itemsList: Item[] = newPostItems.map(item => ({
        type: item.type,
        src: item.src,
        content: item.content
      }));

      let msg = '';
        
      for (let block of newPostItems) {
        if (block.type === "text") {
          msg += block.content + "\\end";
        } else {
          msg += `[${block.src}]` + "\\end";
        }
      }

      const payload = {
        content: msg,
      };

      try {
        const meResponse = await axios.get('/me');
        const postResponse = await axios.post(`/users/${meResponse.data.username}/posts`, payload);
        this.posts.unshift({
          id: postResponse.data.id,
          currentTime: postResponse.data.created_at,
          itemsList: itemsList,
          userName: postResponse.data.author.username,
          likes: 0,
        });
      } catch(error) {
        alert("Не вдалося створити нову публікацію!");
        return;
      }      
    }
  },
});
</script>

<style scoped>
.container-posts {
  display: flex;
  flex-direction: column;
  align-items: 0px; /* Центрування по горизонталі */
  padding: 20px; /* Відступи по краях */
  margin-top: 30px; /* Відступ зверху */
  margin-bottom: 30px;
}
</style>
