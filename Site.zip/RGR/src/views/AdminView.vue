<template>
    <span>Так!!! Хотів образити?? Ми адміни, у нас є ЦУЦIК!</span>
</template>